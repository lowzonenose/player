// local :
var config = { 
 key3d:'b5hd53pk9bbp1447qzygfcpa', // Api key 
 keyFlash:'hpjhmbb9i2ds3qcnzzspr8jf', // Api key 
 keyJs:'e4i6cff4ot440vro0byfkciw', // exemples Api
 keyJsAll:'skhfok2smgcy3pd89y4roz13', // toutes les ressources
 keyJsGpLike:'z1kjcvdfckyjwle548apozj0',
 keyJsOrthos:'spoh098k34u3w7vnewejj4mq',
 keyJsRGE:'pl3v07801fpvf5pw84lt4lht',
 keyJsMobile:'oks7dp0symgwb23gutfe7o49',
 keyJsAlti:'xeo258s5tq8pz51im9p4m1av', // exemples Api sur Service Altimetrique (dev. local p94h6v50lf8zelo6h73gs4i4)
 proxy:"/proxy/perl/proxy.pl?url=" , // Proxy URL for external resources 
 proxyPHP:"/proxy/php/proxy.php?url=" , // Proxy PHP URL for external resources 
 noProxyDomains:['gpp3-wxs-ign-fr.aw.atosorigin.com','gpp3-wxs.ign.fr','wxs.ign.fr'],
 callback:null , // CallBack function used when calling getConfig() 
 ipinfodbKey:'7487f05eb0ed1a6c1b81677ab603faf71e7587ec9c88b8bca0d21d7ae5faa114',
 serverUrl:"http://wxs.ign.fr/$key$/autoconf/" // Autoconfiguration URL 
} 

