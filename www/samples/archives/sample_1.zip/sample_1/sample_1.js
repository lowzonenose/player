    // code javascript Exemple 1
    var iv= null;
    window.onload= function() {
        iv= Geoportal.load(
            // div's ID:
            'viewerDiv',
            // API's keys:
            ['e4i6cff4ot440vro0byfkciw'],
            // FIXME : [config.apiKey],
            {// map's center :
                // longitude:
                lon:2.731525,
                // latitude:
                lat:45.833333
            },
            null,
            {
              language:'fr',
              // FIXME : geormUrl: config.autoconfUrl
              geormUrl:'http://wxs.ign.fr/$key$/autoconf/'
            }
        );
    };